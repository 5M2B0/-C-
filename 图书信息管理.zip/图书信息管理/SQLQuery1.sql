USE [BookDb]
GO
/****** Object:  Table [dbo].[t_admin]    Script Date: 2022/6/13 13:39:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t_admin](
	[id] [varchar](20) NULL,
	[psw] [varchar](20) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t_book]    Script Date: 2022/6/13 13:39:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t_book](
	[id] [varchar](50) NOT NULL,
	[name] [varchar](50) NULL,
	[author] [varchar](20) NULL,
	[press] [varchar](20) NULL,
	[number] [int] NULL,
 CONSTRAINT [PK_t_book] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t_lend]    Script Date: 2022/6/13 13:39:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t_lend](
	[no] [int] IDENTITY(1,1) NOT NULL,
	[uid] [varchar](20) NULL,
	[bid] [varchar](20) NULL,
	[datetime] [datetime] NULL,
	[returnstate] [varchar](50) NULL,
 CONSTRAINT [PK_t_lend] PRIMARY KEY CLUSTERED 
(
	[no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[t_user]    Script Date: 2022/6/13 13:39:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[t_user](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](20) NULL,
	[sex] [char](2) NULL,
	[psw] [varchar](20) NULL,
	[visiteCount] [int] NULL,
 CONSTRAINT [PK_t_user] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[t_admin] ([id], [psw]) VALUES (N'1', N'1')
GO
INSERT [dbo].[t_admin] ([id], [psw]) VALUES (N'1', N'1')
GO
INSERT [dbo].[t_book] ([id], [name], [author], [press], [number]) VALUES (N'1', N'�����̵�����', N'����', N'��������������', 9)
GO
INSERT [dbo].[t_book] ([id], [name], [author], [press], [number]) VALUES (N'2', N'����ʵ��ָ����', N'��ΰ', N'���пƼ���ѧ������', 20)
GO
INSERT [dbo].[t_book] ([id], [name], [author], [press], [number]) VALUES (N'3', N'���������������̳�', N'������', N'�廪��ѧ������', 30)
GO
INSERT [dbo].[t_book] ([id], [name], [author], [press], [number]) VALUES (N'4', N'��ý�弼��Ӧ�ý̳�', N'���ӽ�', N'��е��ҵ������', 220)
GO
SET IDENTITY_INSERT [dbo].[t_lend] ON 
GO
INSERT [dbo].[t_lend] ([no], [uid], [bid], [datetime], [returnstate]) VALUES (15, N'1', N'1', CAST(N'2021-11-25T22:11:52.677' AS DateTime), N'δ��')
GO
SET IDENTITY_INSERT [dbo].[t_lend] OFF
GO
SET IDENTITY_INSERT [dbo].[t_user] ON 
GO
INSERT [dbo].[t_user] ([id], [name], [sex], [psw], [visiteCount]) VALUES (1, N'1', N'��', N'1', 9)
GO
INSERT [dbo].[t_user] ([id], [name], [sex], [psw], [visiteCount]) VALUES (4, N'2', N'��', N'2', 0)
GO
SET IDENTITY_INSERT [dbo].[t_user] OFF
GO
ALTER TABLE [dbo].[t_user] ADD  CONSTRAINT [DF_t_user_visiteCount]  DEFAULT ((0)) FOR [visiteCount]
GO
ALTER TABLE [dbo].[t_user]  WITH CHECK ADD  CONSTRAINT [CK_t_user] CHECK  (([sex]='��' OR [sex]='Ů'))
GO
ALTER TABLE [dbo].[t_user] CHECK CONSTRAINT [CK_t_user]
GO
