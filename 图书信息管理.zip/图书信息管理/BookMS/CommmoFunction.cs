﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace BookMS
{

    public  class CommmoFunction
    {
        /// <summary>
        /// 打开窗体方法
        /// </summary>
        /// <param name="Frm"></param>
        /// <param name="MainPanel"></param>
        public void OpenWindow(Form Frm, Panel MainPanel)
        {
            Frm.TopLevel = false;
            Frm.FormBorderStyle = FormBorderStyle.None;
            Frm.Dock = DockStyle.Fill;
            Frm.Parent = MainPanel;
            Frm.Show();
        }
        /// <summary>
        /// 关闭窗体方法
        /// </summary>
        /// <param name="FrmName"></param>
        /// <param name="MainPanel"></param>
        /// <returns></returns>
        public bool CloseWindow(string FrmName, Panel MainPanel)
        {
            foreach (Control ct in MainPanel.Controls)
            {
                if (ct is Form)
                {
                    Form Frm = (Form)ct;
                    if (Frm.Name == FrmName)
                    {
                        return true;
                    }
                    else
                    {
                        Frm.Close();
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// 本机IP地址获取
        /// </summary>
        /// <returns></returns>
        public string GetIP() 
        {
            IPAddress[] ips = Dns.GetHostEntry(Dns.GetHostName()).AddressList ;
            string ip = "未查询到";
            int i = 0;
            foreach (IPAddress iP in ips) 
            {
                if (iP.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    ip = ips[i].ToString();
                }
                i++;
            }
            return ip;
        }
    }
}
