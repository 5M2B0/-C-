﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class UserAboutForm1 : Form
    {
        private string placeholderText = "亲，1-5分给我打一个分吧！";
        private Color placeholderColor = Color.Gray;
        private Color textColor = Color.Black;
        public UserAboutForm1()
        {
            InitializeComponent();
            InitializeTextBox();
        }
        private void InitializeTextBox()
        {
            textBox1.Text = placeholderText;
            textBox1.ForeColor = placeholderColor;
            textBox1.Enter += textBox1_Enter;
            textBox1.Leave += textBox1_Leave;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text==placeholderText)
            {
                textBox1.Text = "";
                textBox1.ForeColor = textColor;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.Text = placeholderText;
                textBox1.ForeColor = placeholderColor;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int score;
            if (int.TryParse(textBox1.Text,out score))
            {
                if (score>=3)
                {
                    MessageBox.Show("感谢您的认可，我们会越加改进！");
                }
                else
                {
                    MessageBox.Show("请您前往反馈页进行反馈，以帮助我们改进服务！");
                }
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("请输入您的评价分数！");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)&&!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if (char.IsDigit(e.KeyChar)&&(e.KeyChar<'1'||e.KeyChar>'5'))
            {
                e.Handled = true;
            }
        }

        private void UserAboutForm1_Load(object sender, EventArgs e)
        {

        }
    }
}
