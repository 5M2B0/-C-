﻿using DMGT;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class AdminForm : Form
    {
        CommmoFunction commmoFunction = new CommmoFunction();
        public AdminForm()
        {
            InitializeComponent();
            this.Text += "[欢迎管理："+Data.UName+"登陆]";
        
            timer1.Tick += Timer1_Tick;
            timer1.Start();
        }

        /// <summary>
        /// 定时器刷新时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer1_Tick(object sender, EventArgs e)
        {
            tsp_time.Text = "系统时间：" + DateTime.Now.ToString("yyyy-MM-dd tt hh:mm:ss");
        }

        private void 图书管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("AdminBookForm", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new AdminBookForm(), Pnl_Main);
            }
        }

        private void 用户借阅记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("AdminUserLendInfo", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new AdminUserLendInfo(), Pnl_Main);
            }
        }

        private void 用户信息表ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("AdminUserInfo", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new AdminUserInfo(), Pnl_Main);
            }
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("AccessRecordForm", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new AccessRecordForm(), Pnl_Main);
            }
        }
        private void 退出登录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }

        private void AdminForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
