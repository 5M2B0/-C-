﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using DMGT;

namespace BookMS
{
    public partial class UserForm : Form
    {
        CommmoFunction commmoFunction = new CommmoFunction();
        
        public UserForm()
        {
            InitializeComponent();
            this.Text += "[欢迎用户："+Data.UName+"登陆!]";
          
            timer1.Tick += Timer1_Tick;
            timer1.Start();
            
        }

        /// <summary>
        /// 定时器刷新时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer1_Tick(object sender, EventArgs e)
        {
            tsp_time.Text = "系统时间：" +DateTime.Now.ToString("yyyy-MM-dd tt hh:mm:ss");
        }

        private void 图书查看和借阅ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("UserLendForm", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new UserLendForm(), Pnl_Main);
            }
        }

        private void 查看还书和还书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("UserReturnForm", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new UserReturnForm(), Pnl_Main);
            }
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("UserAboutForm1", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new UserAboutForm1(), Pnl_Main);
            }
        }

        private void 反馈ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (commmoFunction.CloseWindow("UserFeedbackForm", Pnl_Main) == false)
            {
                commmoFunction.OpenWindow(new UserFeedbackForm(), Pnl_Main);
            }
        }

        private void UserForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void Pnl_Main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
