﻿using DMGT;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "") 
            {
                if (textBox2.Text == textBox3.Text)
                {
                    try 
                    {
                        string sex = "";
                        if (radioButton1.Checked)
                        {
                            sex = "男";
                        } 
                        else 
                        {
                            sex = "女";
                        }
                        string sql = "insert into "+Common.t_user+" values('"+textBox1.Text+"','"+sex+"','"+textBox2.Text+"','0')";
                        Dao dao = new Dao();
                        if (dao.Execute(sql)>0)
                        {
                            MessageBox.Show("注册成功");
                        }
                        else 
                        {
                            MessageBox.Show("注册失败");
                        }
                        this.Close();
                        dao.DaoClose();
                    } 
                    catch
                    {
                        MessageBox.Show("输入名字相同");
                    }
                }
                else
                {
                    MessageBox.Show("两次输入密码不一致");
                }
            } 
            else 
            {
                MessageBox.Show("输入不能为空");
            }
        }

        private void RegisterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }
    }
}
