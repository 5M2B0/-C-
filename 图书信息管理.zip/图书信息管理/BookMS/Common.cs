﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMS
{
    public static class Common
    {
        public static string Path = @"Data Source=.;Initial Catalog=BookDB;Integrated Security=True";//数据库连接字符串
        public static string t_addmin = "BookDb.dbo.t_admin";
        public static string t_book = "BookDb.dbo.t_book";
        public static string t_lend = "BookDb.dbo.t_lend";
        public static string t_user = "BookDb.dbo.t_user";
    }
}
