﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class AdminBookForm : Form
    {
        public AdminBookForm()
        {
            InitializeComponent();
        }

        private void AdminBookForm_Load(object sender, EventArgs e)
        {
            Table();
            try 
            {
                label2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            }
            catch
            { 
            }
        }
        //从数据库中读取数据显示在表格控件中
        public void Table() 
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_book;
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }      
            dc.Close();
            dao.DaoClose();
        }
        //根据书号进行查询
        public void TableID()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_book+" where id='"+textBox1.Text+"'";
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        /// <summary>
        /// 获取数据
        /// </summary>
        public void TableName()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_book+" where name like '%"+textBox2.Text+"%'";
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        /// <summary>
        /// 删除图书数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // 获取选中的行集合
                DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;

                // 检查是否有选中的行
                if (selectedRows.Count == 0)
                {
                    MessageBox.Show("请先在表格中选中要删除的图书记录", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DialogResult dr = MessageBox.Show("确认删除选中的图书记录吗", "信息提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                // 构建 SQL 语句
                StringBuilder sqlBuilder = new StringBuilder();
                sqlBuilder.Append("DELETE FROM " + Common.t_book + " WHERE id IN (");

                // 遍历选中的行，构建 SQL 语句
                foreach (DataGridViewRow row in selectedRows)
                {
                    string id = row.Cells[0].Value.ToString();
                    sqlBuilder.Append("'" + id + "',");
                }

                // 移除最后一个逗号并添加右括号
                sqlBuilder.Remove(sqlBuilder.Length - 1, 1);
                sqlBuilder.Append(")");

                // 执行 SQL 语句
                string sql = sqlBuilder.ToString();
                Dao dao = new Dao();
                int affectedRows = dao.Execute(sql);
                dao.DaoClose();

                // 根据受影响的行数显示删除结果
                if (affectedRows > 0)
                {
                    MessageBox.Show("成功删除" + affectedRows + "条记录", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Table(); // 重新加载表格数据
                }
                else
                {
                    MessageBox.Show("删除失败", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("删除操作失败：" + ex.Message, "错误提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// 修改图书数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string author = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string press = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string num = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                AdminModifyForm adminModifyForm = new AdminModifyForm(id, name, author, press, num);
                adminModifyForm.ShowDialog();
                Table();//更新
            }
            catch
            {
                MessageBox.Show("Erroer");
            }
        }
        /// <summary>
        /// 数据表点击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + " " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }
        /// <summary>
        /// 按Id查书
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            TableID();
        }
        /// <summary>
        /// 按书名查书
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            TableName();
        }
        /// <summary>
        /// 刷新数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            Table();
            textBox1.Text = "";
            textBox2.Text = "";
        }
        /// <summary>
        /// 添加图书弹窗
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            AdminAddBookForm adminAddBookForm = new AdminAddBookForm();
            adminAddBookForm.ShowDialog();
            Table();
        }
        /// <summary>
        /// 导入数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_input_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.InitialDirectory = Application.StartupPath + "\\SaveFile";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFile.FileName;
                string[] strs = File.ReadAllLines(fileName, Encoding.UTF8);
                StringBuilder datatext = new StringBuilder();
                Dao dao = new Dao();
                //string sql = $"truncate table {Common.t_book}";
                //dao.Execute(sql);
                for (uint i = 0; i < strs.Length; i++)
                {
                    //拆分数组
                    datatext.Append(strs[i] + "\r\n");
                    string[] s = strs[i].Split(new char[] { '\t' }, StringSplitOptions.RemoveEmptyEntries);
                    try
                    {
                        string sql1 = "insert into "+Common.t_book+" values('"+s[0]+"','"+s[1]+"','"+s[2]+"','"+s[3]+"','"+s[4]+"')";
                        dao.Execute(sql1);
                    }
                    catch
                    {
                       
                    }
                }
                Table();
            }
        }
        /// <summary>
        /// 导出数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_outPut_Click(object sender, EventArgs e)
        {
            //保存
            string SaveFilePath = CreateFilePath(Application.StartupPath);
            string fileName = "图书数据"+DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "*.txt|*.文本文件";
            saveFile.InitialDirectory = SaveFilePath;
            saveFile.FileName = fileName;
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                StringBuilder dataSave = new StringBuilder();
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    dataSave.Append(dataGridView1.Rows[i].Cells[0].Value + "\t" + dataGridView1.Rows[i].Cells[1].Value + "\t" + dataGridView1.Rows[i].Cells[2].Value + "\t" + dataGridView1.Rows[i].Cells[3].Value + "\t" + dataGridView1.Rows[i].Cells[4].Value + Environment.NewLine);
                }
                File.WriteAllText(saveFile.FileName, dataSave.ToString(), Encoding.UTF8);
            }
        }
        /// <summary>
        /// 创建初始路径
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        public static string CreateFilePath(string root)
        {
            string path;
            path = root + @"\" + DateTime.Now.ToString("yyyyMM");
            if (Directory.Exists(path))
            {
                path += @"\" + DateTime.Now.ToString("dd");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
            }
            else
            {
                Directory.CreateDirectory(path);
                path = CreateFilePath(root);
            }
            return path;
        }
    }
}
