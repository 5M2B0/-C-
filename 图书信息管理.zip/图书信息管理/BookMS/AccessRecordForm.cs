﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class AccessRecordForm : Form
    {
        public AccessRecordForm()
        {
            InitializeComponent();
            Table();
        }

        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_user;
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(),dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }

        private void AccessRecordForm_Load(object sender, EventArgs e)
        {

        }
    }
}
