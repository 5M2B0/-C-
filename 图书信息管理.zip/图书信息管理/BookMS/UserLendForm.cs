﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class UserLendForm : Form
    {
        public UserLendForm()
        {
            InitializeComponent();
            Table();
        }

        private void UserLendForm_Load(object sender, EventArgs e)
        {

        }
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_book;
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            int number = int.Parse(dataGridView1.SelectedRows[0].Cells[4].Value.ToString());
            if (number < 1)
            {
                MessageBox.Show("图书已被借完，请联系管理员添加图书");
            }
            else
            {
                string sql = "insert into "+Common.t_lend+" (uid,bid,datetime,returnstate) values('"+Data.Uid+"','"+id+"',getdate(),'未还');" +
                    " update "+Common.t_book+" set number=number-1 where id='"+id+"'";
                Dao dao = new Dao();
                if (dao.Execute(sql) > 1)
                {
                    MessageBox.Show("图书借阅成功");
                    Table();
                }
                else 
                {
                    MessageBox.Show("图书借阅失败");
                }
            }
        }
    }
}
