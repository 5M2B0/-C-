﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMS
{
    public class Data
    {
        public static string Uid = "", UName = "";//登陆用户的ID和姓名
    }
}
