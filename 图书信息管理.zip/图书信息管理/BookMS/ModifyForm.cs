﻿using DMGT;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class ModifyForm : Form
    {
        public ModifyForm(string id,string name,string sex,string psw)
        {
            InitializeComponent();
            tbx_id.Text = id;
            tbx_name.Text = name;
            if (sex.Equals("男"))
                radioButton1.Checked = true;
            else
                radioButton2.Checked = true;
            tbx_pswd.Text = psw;
        }

        private void btn_Modify_Click(object sender, EventArgs e)
        {
            if (tbx_name.Text != ""  && tbx_pswd.Text != "")
            {
                string sex = "";
                if (radioButton1.Checked)
                {
                    sex = "男";
                }
                else 
                {
                    sex = "女";
                }
                string sql = "update "+Common.t_user+" set name='"+tbx_name.Text+"',sex='"+sex+"',psw='"+tbx_pswd.Text+"' where id='"+tbx_id.Text+"'";
                Dao dao = new Dao();
                if (dao.Execute(sql) > 0)
                {
                    MessageBox.Show("修改成功");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("修改失败");
                }
                dao.DaoClose();
            }
            else
            {
                MessageBox.Show("输入不能为空");
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ModifyForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void ModifyForm_Load(object sender, EventArgs e)
        {

        }
    }
}
