﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class AdminModifyForm : Form
    {
        string ID = "";
        public AdminModifyForm()
        {
            InitializeComponent();
        }
        public AdminModifyForm(string id,string name,string author,string press,string num)
        {
            InitializeComponent();
            ID = id;
            textBox1.Text = id;
            textBox2.Text = name;
            textBox3.Text = author;
            textBox4.Text = press;
            textBox5.Text = num;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                string sql = "update "+Common.t_book+" set id='"+textBox1.Text+"',name='"+textBox2.Text+"',author='"+textBox3.Text+"',press='"+textBox4.Text+"',number="+textBox5.Text+" where id='"+ID+"'";
                Dao dao = new Dao();
                if (dao.Execute(sql) > 0) 
                {
                    MessageBox.Show("修改成功");
                    this.Close();
                }
                else 
                {
                    MessageBox.Show("修改失败");
                }
                dao.DaoClose();
            }
            else
            {
                MessageBox.Show("输入不能为空");
            }
        }

        private void AdminModifyForm_Load(object sender, EventArgs e)
        {

        }
    }
}
