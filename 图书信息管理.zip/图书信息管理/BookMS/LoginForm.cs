﻿using DMGT;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (tbx_Name.Text != "" && tbx_pswd.Text != "") 
            {
                login();
            }
            else 
            {
                MessageBox.Show("填入参数不能为空，请重新输入！");
            }
        }

        private void login() 
        {
            //用户
            if (radioButtonUser.Checked) 
            {
                Dao dao = new Dao();
                //string sql1 = "Select *from t_user where id='"+tbx_Name.Text+"' and psw='"+tbx_pswd.Text+"'";
                //string sql2 = string.Format("Select *from t_user where id='{0}' and psw='{1}'",tbx_Name.Text,tbx_pswd.Text);
                string sql = "Select *from "+Common.t_user+" where name='"+tbx_Name.Text+"' and psw='"+tbx_pswd.Text+"'";
                IDataReader dc= dao.reader(sql);
                if (dc.Read())
                {
                    Data.Uid = dc["id"].ToString();
                    Data.UName = dc["name"].ToString();
                    int Logincount = Convert.ToInt32(dc["visiteCount"])+1;
                    MessageBox.Show("登陆成功");
                    string sql1 = "update "+Common.t_user+" set visiteCount='"+Logincount +"' where id='"+dc["id"]+"'";
                    dao.Execute(sql1);
                    UserForm userForm = new UserForm();
                    this.Hide();
                    userForm.ShowDialog();
                    this.Show();
                }
                else 
                {
                    MessageBox.Show("登陆失败");
                }
                dao.DaoClose();
            }
            //管理员
            else
            {
                Dao dao = new Dao();
                string sql = "Select *from "+Common.t_addmin+" where id='"+tbx_Name.Text+"' and psw='"+tbx_pswd.Text+"'";
                IDataReader dc = dao.reader(sql);
                if (dc.Read())
                {
                    MessageBox.Show("登陆成功");
                    AdminForm adminForm = new AdminForm();
                    this.Hide();
                    adminForm.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("登陆失败");
                }
                dao.DaoClose();
            }
        }

        private void btn_Cancle_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ExitMsg exitmsg = new ExitMsg();
            exitmsg.ShowDialog();
            e.Cancel = true;
        }
    }
}
