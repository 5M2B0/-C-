﻿using DMGT;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BookMS
{
    public partial class UserFeedbackForm : Form
    {
        private string placeholderText = "亲，大胆的说出来吧，这样我们才会进一步的去改进！";
        private Color placeholderColor = Color.Gray;
        private Color textColor = Color.Black;
        public UserFeedbackForm()
        {
            InitializeComponent();
            InitializeTextBox();
        }
        private void InitializeTextBox()
        {
            textBox2.Text = placeholderText;
            textBox2.ForeColor = placeholderColor;
            textBox2.Enter += textBox2_Enter;
            textBox2.Leave += textBox2_Leave;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == placeholderText)
            {
                textBox2.Text = "";
                textBox2.ForeColor = textColor;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                textBox2.Text = placeholderText;
                textBox2.ForeColor = placeholderColor;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userInput = textBox2.Text;
            if (userInput==placeholderText||string.IsNullOrWhiteSpace(userInput))
            {
                MessageBox.Show("请输入反馈内容！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Regex.IsMatch(userInput,"^[a-zA-Z0-9]*$"))
            {
                MessageBox.Show("输入不能全为英文或数字！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Text="";
                return;
            }
            MessageBox.Show("反馈成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            textBox2.Text=placeholderText;
            textBox2.ForeColor=placeholderColor;
            textBox2.Text="";
        }

        private void UserFeedbackForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //ExitMsg exitmsg = new ExitMsg();
            //exitmsg.ShowDialog();
            //e.Cancel = true;
            //if (exitmsg.ShowDialog()==DialogResult.OK)
            //{
            //    Application.Exit();
            //}
            //else
            //{
            //    e.Cancel = false;
            //}
        }

        private void UserFeedbackForm_Load(object sender, EventArgs e)
        {

        }
    }
}
