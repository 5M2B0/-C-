﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookMS
{
    public partial class UserReturnForm : Form
    {
        public UserReturnForm()
        {
            InitializeComponent();
            Table();
        }
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空旧数据
            Dao dao = new Dao();
            string sql = "select *from "+Common.t_lend+" where uid='"+Data.Uid+"'";
            IDataReader dc = dao.reader(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows[0].Cells[4].Value.ToString() == "已归还")
            {
                MessageBox.Show("图书已归还");
            }
            else 
            {
                string id = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string no = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string sql = "update "+Common.t_lend+" set returnstate='已归还'where no='"+no+"';update "+Common.t_book+" set number=number+1 where id='"+id+"'";
                Dao dao = new Dao();
                if (dao.Execute(sql) > 1)
                {
                    MessageBox.Show("归还成功");
                    Table();
                }
                else
                {
                    MessageBox.Show("归还失败");
                }
                dao.DaoClose();
            }
        }
    }
}
